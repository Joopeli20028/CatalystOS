# CatalystNotes
Catalyst os HTML notes app "html compile ZIP"

Easy to use light weight html text editor.

# How To Use
1. Extract the zip 
2. Open SRC folder
3. Run the .HTML file
4. Use the editor
