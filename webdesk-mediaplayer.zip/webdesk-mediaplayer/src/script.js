document.getElementById('fileInput').addEventListener('change', function(event) {
  const file = event.target.files[0];
  const preview = document.getElementById('preview');
  const audioPlayer = document.getElementById('audioPlayer');
  const videoPlayer = document.getElementById('videoPlayer');
  const videoControls = document.querySelector('.video-controls');

  // Reset previous preview
  preview.innerHTML = '';

  // Check file type and display preview
  if (file.type.startsWith('image/')) {
    const img = document.createElement('img');
    img.src = URL.createObjectURL(file);
    img.onload = function() {
      URL.revokeObjectURL(this.src);
    };
    preview.appendChild(img);
  } else if (file.type === 'audio/mpeg') {
    audioPlayer.src = URL.createObjectURL(file);
    audioPlayer.classList.remove('hidden');
  } else if (file.type === 'video/mp4') {
    videoPlayer.src = URL.createObjectURL(file);
    videoPlayer.classList.remove('hidden');
    videoControls.classList.remove('hidden');
  } else {
    alert('Unsupported file type!');
  }
});

// Video controls
document.getElementById('playPauseButton').addEventListener('click', function() {
  const videoPlayer = document.getElementById('videoPlayer');
  if (videoPlayer.paused || videoPlayer.ended) {
    videoPlayer.play();
    this.innerHTML = '&#10074;&#10074;'; // Pause icon
  } else {
    videoPlayer.pause();
    this.innerHTML = '&#9658;'; // Play icon
  }
});

document.getElementById('seekBar').addEventListener('input', function() {
  const videoPlayer = document.getElementById('videoPlayer');
  const seekTime = videoPlayer.duration * (this.value / 100);
  videoPlayer.currentTime = seekTime;
});

document.getElementById('videoPlayer').addEventListener('timeupdate', function() {
  const videoPlayer = document.getElementById('videoPlayer');
  const seekBar = document.getElementById('seekBar');
  const currentTime = videoPlayer.currentTime;
  const duration = videoPlayer.duration;
  const seekBarValue = (currentTime / duration) * 100;
  seekBar.value = seekBarValue;
});

document.getElementById('muteButton').addEventListener('click', function() {
  const videoPlayer = document.getElementById('videoPlayer');
  if (videoPlayer.muted) {
    videoPlayer.muted = false;
    this.innerHTML = '&#128266;'; // Unmute icon
  } else {
    videoPlayer.muted = true;
    this.innerHTML = '&#128263;'; // Mute icon
  }
});

document.getElementById('volumeBar').addEventListener('input', function() {
  const videoPlayer = document.getElementById('videoPlayer');
  videoPlayer.volume = this.value;
});
